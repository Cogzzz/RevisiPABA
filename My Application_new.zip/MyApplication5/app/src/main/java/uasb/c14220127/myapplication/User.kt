package uasb.c14220127.myapplication

data class User(
    val name: String,
    val email: String,
    val phone: String,
    val username: String, // Add username field
    val password: String,
    val address: String?
)
